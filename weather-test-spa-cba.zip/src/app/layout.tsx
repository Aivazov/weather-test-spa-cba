import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import ReduxProvider from './ReduxProvider';
import './globals.css';
import WeatherInitializer from '@/components/WeatherInitializer';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Weather App',
  description: 'Weather application with city search',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang='en'>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ReduxProvider>
          <WeatherInitializer />
          {children}
        </ReduxProvider>
      </body>
    </html>
  );
}
